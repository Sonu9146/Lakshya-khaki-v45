# Lakshya Khaki V25 – Firebase Integration Foundation

Added Firebase Authentication and Firestore dependencies using the Firebase BoM.
The app remains demo/local until a Firebase project is connected.

Next required setup in Android Studio:
1. Create a Firebase project.
2. Register the Android package: com.lakshyakhaki.app
3. Download google-services.json.
4. Put it in app/google-services.json.
5. Enable Authentication (Email/Google as desired) and Firestore.
6. Add the Google services Gradle plugin in the project build configuration.
7. Then wire Community posts/replies/likes to Firestore.

Do not share API keys, passwords, or other credentials in chat.
