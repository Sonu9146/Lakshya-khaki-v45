package com.lakshyakhaki.app.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class CommunitySyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    private val dao = CommunityOutboxDatabase.get(appContext).communityOutboxDao()
    private val firestore = FirebaseFirestore.getInstance()

    override suspend fun doWork(): Result {
        val user = FirebaseAuth.getInstance().currentUser ?: return Result.success()
        val actions = dao.pending().filter { it.uid == user.uid }
        if (actions.isEmpty()) return Result.success()

        var failed = false
        for (action in actions) {
            try {
                when (action.type) {
                    CommunityOfflineRepository.TYPE_POST -> syncPost(action)
                    CommunityOfflineRepository.TYPE_LIKE -> syncLike(action)
                    CommunityOfflineRepository.TYPE_REPLY -> syncReply(action, user.uid)
                }
                dao.delete(action.id)
            } catch (_: Exception) {
                dao.update(action.copy(attempts = action.attempts + 1))
                failed = true
            }
        }
        return if (failed) Result.retry() else Result.success()
    }

    private suspend fun syncPost(action: PendingCommunityAction) {
        val ref = firestore.collection("posts").document("offline_${action.id}")
        val data = hashMapOf<String, Any>(
            "authorId" to action.uid,
            "authorName" to action.authorName.ifBlank { "User" },
            "text" to action.text,
            "imageUrl" to "",
            "imagePublicId" to "",
            "videoUrl" to "",
            "likes" to 0L,
            "likedBy" to emptyList<String>(),
            "replies" to 0L,
            "createdAt" to FieldValue.serverTimestamp()
        )
        ref.set(data).await()
    }

    private suspend fun syncLike(action: PendingCommunityAction) {
        val userId = action.uid
        val ref = firestore.collection("posts").document(action.postId)
        firestore.runTransaction { tx ->
            val snap = tx.get(ref)
            val ids = (snap.get("likedBy") as? List<*>)?.filterIsInstance<String>()?.toMutableList() ?: mutableListOf()
            if (action.desiredLiked && !ids.contains(userId)) ids.add(userId)
            if (!action.desiredLiked) ids.remove(userId)
            tx.update(ref, mapOf("likedBy" to ids, "likes" to ids.size.toLong()))
        }.await()
    }

    private suspend fun syncReply(action: PendingCommunityAction, uid: String) {
        val replyRef = firestore.collection("posts").document(action.postId)
            .collection("replies").document("offline_${action.id}")
        replyRef.set(hashMapOf<String, Any>(
            "authorId" to uid,
            "authorName" to action.authorName.ifBlank { "User" },
            "text" to action.text,
            "createdAt" to FieldValue.serverTimestamp(),
            "parentId" to action.parentId
        )).await()
        firestore.collection("posts").document(action.postId)
            .update("replies", FieldValue.increment(1)).await()
    }
}
