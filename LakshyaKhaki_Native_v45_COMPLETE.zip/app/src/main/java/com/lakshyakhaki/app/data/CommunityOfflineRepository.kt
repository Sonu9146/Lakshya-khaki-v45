package com.lakshyakhaki.app.data

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.UUID

class CommunityOfflineRepository(private val context: Context) {
    private val dao = CommunityOutboxDatabase.get(context).communityOutboxDao()

    suspend fun queuePost(uid: String, authorName: String, text: String) {
        dao.insert(PendingCommunityAction(uid = uid, type = TYPE_POST, text = text, authorName = authorName))
        scheduleSync()
    }

    suspend fun queueLike(uid: String, postId: String, desiredLiked: Boolean) {
        dao.insert(PendingCommunityAction(uid = uid, type = TYPE_LIKE, postId = postId, desiredLiked = desiredLiked))
        scheduleSync()
    }

    suspend fun queueReply(uid: String, postId: String, authorName: String, text: String, parentId: String = "") {
        dao.insert(PendingCommunityAction(uid = uid, type = TYPE_REPLY, postId = postId, authorName = authorName, text = text, parentId = parentId))
        scheduleSync()
    }

    private fun scheduleSync() {
        val request = OneTimeWorkRequestBuilder<CommunitySyncWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "community-outbox-sync-${UUID.randomUUID()}", ExistingWorkPolicy.KEEP, request
        )
    }

    companion object {
        const val TYPE_POST = "POST"
        const val TYPE_LIKE = "LIKE"
        const val TYPE_REPLY = "REPLY"
    }
}
