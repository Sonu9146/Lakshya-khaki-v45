package com.lakshyakhaki.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [PendingCommunityAction::class],
    version = 1,
    exportSchema = false
)
abstract class CommunityOutboxDatabase : RoomDatabase() {
    abstract fun communityOutboxDao(): CommunityOutboxDao

    companion object {
        @Volatile
        private var INSTANCE: CommunityOutboxDatabase? = null

        fun get(context: Context): CommunityOutboxDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    CommunityOutboxDatabase::class.java,
                    "lakshya_khaki_community_outbox.db"
                ).build().also { INSTANCE = it }
            }
    }
}
