# V37 — Media Community

Version 3.9.0 / versionCode 34.

## Added
- Image picker for Community posts.
- Firebase Storage upload for post images.
- Image preview before publishing.
- Image display in Community feed and Post Detail.
- Profile photo picker and Firebase Storage upload.
- Public profile avatar display.
- `imageUrl` on Firestore posts and `avatarUrl` on user profiles.
- `storage.rules` with authenticated owner-only writes.

## Firebase setup
1. Enable Firebase Storage in the Firebase console.
2. Publish `storage.rules` from this project.
3. The app uses Firebase Storage paths `post_images/{uid}/...` and `profile_images/{uid}/...`.

## Note
Actual upload/display requires a Firebase project with Storage enabled and valid Firebase configuration. This source was not compiled locally because an Android SDK/Gradle build environment is not available here.
