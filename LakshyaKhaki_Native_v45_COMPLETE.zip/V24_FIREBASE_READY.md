# Lakshya Khaki V24 – Firebase-ready Community

V24 prepares the Community module for a real online backend:
- Community post model
- Reply model
- Like model
- Online-ready UI marker
- Premium-ready structure retained

This package intentionally does not contain a Firebase project configuration or API credentials.
To make the feed truly multi-user, the next setup requires creating a Firebase project and adding its `google-services.json` to the Android app, then wiring Firestore/Auth.

No credentials are embedded in this ZIP.
