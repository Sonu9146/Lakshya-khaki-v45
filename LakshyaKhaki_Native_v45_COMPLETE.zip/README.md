# Lakshya Khaki Native v13

Native Android Jetpack Compose project for Maharashtra Police Bharti preparation.

Includes:
- Home dashboard
- Study subjects
- Subject and topic-wise timed Mock Tests
- 30 sec/question timer
- Quiz result tracking
- Ground Tracker: 1600m, 100m, Shot Put
- Progress dashboard
- Achievements and streaks
- Daily Goals
- Daily reminders
- Mistake Book
- Offline MCQ bank
- Premium dark Material 3 UI

Open this folder in Android Studio and sync Gradle to build the APK.


## V21 Maths Syllabus
- Added the complete 46-chapter Maths syllabus shown in the supplied book contents pages.
- Maths Study now opens a dedicated syllabus screen with expandable chapter-wise types.
- Chapter 1 Numbers and Chapter 2 Fractions include the terminology/types visible in the supplied pages.
- For chapters where the supplied images show only the chapter title, additional type breakdowns are study-oriented subdivisions added for app navigation and practice.
- Version 2.2.0 / versionCode 17.


## V32
Notifications Center, FCM receive service, community search, and V31 compile-reference fixes. Version 3.4.0 / code 29.


V41: real Google Sign-In added with Credential Manager. See V41_GOOGLE_LOGIN.md.

## V44 — Security + Offline-first foundation
- Firestore and Realtime Database rules are authentication-first and deny-by-default where appropriate.
- Community text posts, likes/unlikes and replies use a Room outbox and WorkManager network sync.
- Image posts still require internet for Cloudinary upload.
- Release builds enable R8/minification and resource shrinking.
- Community data layer is being incrementally separated from the Compose UI; full MVVM screen extraction is intentionally staged to avoid breaking existing features.
- Version 4.4.0 / versionCode 40.
