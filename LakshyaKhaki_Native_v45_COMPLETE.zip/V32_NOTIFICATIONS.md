# Lakshya Khaki V32 — Notifications + Community Search

## Added
- Notification Center screen
- Daily reminder controls surfaced in the notification center
- Firebase Cloud Messaging dependency and `LakshyaFirebaseMessagingService` for push notification display
- Community post search by author/name/text
- Fixed V31 navigation references and duplicate report branch that could prevent compilation
- Version: 3.4.0 (versionCode 29)

## Firebase note
FCM receiving is wired in the Android app. Actual remote push delivery still needs a trusted sender such as Firebase Console test messaging or Cloud Functions/server code. No server credentials are embedded in the app.

## Build
Open the project in Android Studio, let Gradle sync, then build `app`.
